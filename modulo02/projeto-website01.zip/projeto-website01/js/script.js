var txtQueMuda = document.getElementById("courses")

// txtQueMuda.setAttribute('style','background-color: #000')

txtQueMuda.addEventListener('click', displayDialog)

function displayDialog(){
  alert('Voce será direcionado para outra página')
}